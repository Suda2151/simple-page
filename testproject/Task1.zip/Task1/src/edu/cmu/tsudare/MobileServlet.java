package edu.cmu.tsudare;

import org.jose4j.json.internal.json_simple.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import java.util.TreeMap;

public class MobileServlet extends HttpServlet {

    private static Map memory = new TreeMap();

    static  int status =0;
    MobileModel mm = new MobileModel();
     //MobileServlet ms = new MobileServlet();
     @Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{

        System.out.println("Servletside is working");  //checking purpose

        System.out.println(request.getPathInfo());
        String name = (request.getPathInfo()).substring(1);

        if(name.equals("")) {
            //mm.searchFromAPI(name);
            return;
        }
         PrintWriter out = response.getWriter();
         //out.println(mm.searchFromAPI(name));
         out.println("test");

    }

/*
    public void search(String searchWord, MainActivity ma){
        this.ma = ma;
        mm.search(searchWord,ma);
    }
*/

/*
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("console: doGet is working");

        String result ="";
        System.out.println(request.getPathInfo().toString());
        String name = (request.getPathInfo()).substring(1);

        mm.search(name,mm);

        while(ms.getStatus() == 0){}

        response.setStatus(ms.getStatus());
        response.setContentType("text/plain;charset=UTF-8");

        PrintWriter out = response.getWriter();
        out.println(result);




    }
*/

    //public void resultOperation(Bitmap pic){
      //  ma.showingPicture(pic);
    //}

 /*
    public void resultOperation2(JSONObject array) throws IOException {

        System.out.println("The monileservlet side received Array");
        System.out.println(array.toString());
        System.out.println(array.get("id"));

        //Bitmap bitmap = mm.getImage(array.get("url").toString());

        //ByteArrayOutputStream baos=new  ByteArrayOutputStream();
        //bitmap.compress(Bitmap.CompressFormat.PNG,100, baos);
        //byte [] b=baos.toByteArray();
        //String temp= Base64.encodeToString(b, Base64.DEFAULT);

        //array.put("bitmap",temp);

        System.out.println("The latest array is : "+array.toString());

        ma.showingPicture(array);
    }

    public void setStatus(int status){
        this.status = status;}

     public int getStatus(){
        return  this.status;  }

*/

}
