package edu.cmu.tsudare;


import org.jose4j.json.internal.json_simple.JSONArray;
import org.jose4j.json.internal.json_simple.JSONObject;
import org.jose4j.json.internal.json_simple.parser.JSONParser;
import org.jose4j.json.internal.json_simple.parser.ParseException;

import java.io.*;
import java.net.*;
import java.util.Collection;
import java.util.Random;

public class MobileModel {
    int statusStore = 0;

    MobileServlet ms = null;
    //MobileModel mm = null;
    static int status= 0;
    static String urlInfo = null;
    private String apiKey = "cyRTTE3ugdXjFPDlM6udr3CpVHbSjplyM7kX1C6SjN8";



        public JSONObject searchFromAPI(String searchWord) throws IOException {


            searchWord = URLEncoder.encode(searchWord,"UTF-8");

            String searchURL = "https://api.unsplash.com/search/photos?query="
                    + searchWord
                    +"&per_page=30"  //at mots 30 information can be retrieved per a search
                    + "&client_id="
                    + apiKey;

            String response = "";
            BufferedReader reader;
            String line;
            StringBuffer responseContent = new StringBuffer();

            String response1= null;
            JSONArray array = null;
            JSONObject jo = null;

            try{

                URL url = new URL(searchURL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                connection.setConnectTimeout(10000);
                connection.setRequestProperty("Content-Type", "application/jason; charset=UTF-8");
                //connection.setDoOutput(true);
                connection.setDoInput(true);
                connection.setRequestMethod("GET");

                status = connection.getResponseCode();
                statusStore = status;
                
                //ms.setStatus(status);

                if(status > 299){
                    reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    while((line = reader.readLine())!= null){
                        responseContent.append(line);
                    }
                    reader.close();
                }else{
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    while((line = reader.readLine())!= null){
                        responseContent.append(line);
                    }
                    reader.close();
                }
                System.out.println(responseContent.toString()); // Check Status

                InputStream inP = new BufferedInputStream(connection.getInputStream());

                System.out.println("ResultStr is :"+responseContent.toString());

                JSONParser parser = new JSONParser();
                JSONObject jobjt = null;


                try {
                    //To store the date from string to JSONObject
                    //Using Jason parser to accommodate with JSONObject
                    jobjt = (JSONObject) parser.parse(responseContent.toString());
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                System.out.println("JSON ID"+jobjt.get("results").toString());
                //System.out.println("raw is :" + jobjt.get("raw").toString());

                // response = jobjt.get("regular").toString();
                String testStr = null;
                String linkStr = null;
                String userName = null;

                array = new JSONArray((Collection) jobjt.get("results"));

                int countTest = array.size();
                System.out.println("Array size is :" + countTest);


                //JSONArray array = new JSONArray(jobjt.get("resilts").toString());


                ////This is to retrieve specific photo info by random retrieving.
                int targetNum = new Random().nextInt(countTest);
                System.out.println("targetNum is :"+targetNum);
                JSONObject jsonObject = (JSONObject)array.get(targetNum);
                String id = jsonObject.get("id").toString();

                //this is for retrieving array of array
                String photoUrls = jsonObject.get("urls").toString();
                JSONParser p = new JSONParser();
                JSONObject urlJsonInfo = (JSONObject)p.parse(photoUrls);
                linkStr = urlJsonInfo.get("regular").toString();

                String userInfo = jsonObject.get("user").toString();
                JSONParser p1 = new JSONParser();
                JSONObject userJsonInfo = (JSONObject)p1.parse(userInfo);
                userName = userJsonInfo.get("username").toString();

                System.out.println(id + "  "+userName+ "  "+ linkStr);

                jo = new JSONObject();
                jo.put("id",id);
                jo.put("url",linkStr);
                jo.put("username",userName);

                System.out.println("JSONObject is :"+jo.toString());
/*
                ////in case of retrieving 10 candidates as array, the following will be used.
                for (int i =0 ; i<10 ; i++){
                    JSONObject job = (JSONObject) array.get(i);
                    // JSONObject job = array.getJSONObject(i);
                    String id = job.get("id").toString();
                    String color = job.get("color").toString();
                    //   String photoUrl = job.getJSONObject("links").getString("html");
                    String photoUrl = job.get("urls").toString();

                    JSONParser p = new JSONParser();
                    JSONObject hub = (JSONObject)p.parse(photoUrl);

                    //JSONArray array2 = new JSONArray(Collections.singleton(photoUrl));
                    //JSONObject job2 = (JSONObject) array2.get(0);
                    testStr = hub.get("regular").toString();

                    System.out.println(id + "  " + color+"  "+testStr);

                }
*/

/*
                try {
                    URL u = new URL(linkStr);
                    //return getImage(u);

                    Bitmap bitmap = getImage(u);
                    ByteArrayOutputStream baos=new  ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG,100, baos);
                    byte [] b=baos.toByteArray();
                    String temp= Base64.encodeToString(b, Base64.DEFAULT);

                    jo.put("bitmap",temp);


                } catch (Exception e) {
                    e.printStackTrace();
                    return null; // so compiler does not complain
                }
*/


/////
                //response1 = testStr;

                //return response1;

            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }



            /////
/*
            //This is for retrieving array info
            urlInfo = response1;
            URL targetURL = new URL(response1);
            System.out.println("This is just before array testing print");
            System.out.println(array.toString());
*/
            //return getImage(targetURL);
            // the following is a just URL
            //return response1;

            return jo;
        }

/*
        private Bitmap getImage(final URL urlStr) {
            try {
                final URLConnection conn = urlStr.openConnection();
                conn.connect();
                System.out.println("Target URL is : "+urlStr.toString());
                BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
                Bitmap bm = BitmapFactory.decodeStream(bis);
                bis.close();
                System.out.println("The contents of bm is :" + bm.toString());
                return bm;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }

        }

*/





}
