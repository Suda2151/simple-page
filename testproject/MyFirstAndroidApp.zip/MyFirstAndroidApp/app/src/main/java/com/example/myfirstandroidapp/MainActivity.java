package com.example.myfirstandroidapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        MainActivity ma = new MainActivity();
        MobileServlet ms = new MobileServlet();


        Button btnSubmit;
        final TextView txtDisplay;
        final EditText editText;

        btnSubmit = (Button)findViewById(R.id.btnSubmit);
        //txtDisplay = (TextView)findViewById(R.id.txtDisplay0);
        txtDisplay = (TextView)findViewById(R.id.txtDisplay);
        editText = (EditText)findViewById(R.id.edittxt);

        //define the oneclick methof of btnSubmit
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //txtDisplay.setText(editText.getText());

                String resultFromServlet = read(editText.getText().toString());
                txtDisplay.setText(resultFromServlet);

                Toast.makeText(MainActivity.this, "You clicked submit!" , Toast.LENGTH_SHORT).show();

            }
        });

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public static int doGet(String searchWord, Result r){

        r.setValue("");
        String response = "";
        HttpURLConnection connection;
        int status = 0;

        try{

            URL url = new URL("http://localhost:8080/MyFirstAndroidApp/MobileServletjava/"+"//"+searchWord);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept","text/plain");

            status = connection.getResponseCode();

            if (status != 200) {
                // not using msg
                String msg = connection.getResponseMessage();
                return connection.getResponseCode();
            }
            String output = "";
            // things went well so let's read the response
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (connection.getInputStream())));

            while ((output = br.readLine()) != null) {
                response += output;

            }

            connection.disconnect();


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return 0;
    }

    public static String read(String searchWord){
        Result r = new Result();
        int status = 0;
        if((status = doGet(searchWord,r)) !=200){
            return "HTTP Connection Error Code :" + status;
        }else{
            return r.getValue();
        }

    }

    static class Result {
        String value;

        public String getValue() {
            return value;
        }
        public void setValue(String value) {
            this.value = value;
        }
    }

}
