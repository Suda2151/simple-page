package com.example.myfirstandroidapp;

import org.jose4j.json.internal.json_simple.JSONObject;
import org.jose4j.json.internal.json_simple.parser.JSONParser;
import org.jose4j.json.internal.json_simple.parser.ParseException;
import org.json.JSONArray;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.TreeMap;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MobileServlet extends HttpServlet {

        private static Map memoryMap = new TreeMap();

       @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("Console: doGet is actually working");

        MobileModel mm = new MobileModel();

        String result = "";
        String name = (request.getPathInfo().substring(1));

        //mm.searchRequest(name); instead of line 33
        String testStr = null;
        String testStr2 = null;

        for (int i = 0; i<10 ; i++){
            JSONObject jo = (JSONObject) mm.searchRequest(name).get(i);
            String id = jo.get("id").toString();
            String color = jo.get("color").toString();
            String photoUrl = jo.get("urls").toString();
            String tag = jo.get("tag").toString();

            JSONParser p = new JSONParser();
            try {
                JSONObject hub = (JSONObject)p.parse(photoUrl);
                testStr = hub.get("regular").toString();
            } catch (ParseException e) {
                e.printStackTrace();
            }

            JSONParser p2 = new JSONParser();
            try {
                JSONObject hub = (JSONObject)p2.parse(tag);
                testStr2 = hub.get("title").toString();
            } catch (ParseException e) {
                e.printStackTrace();
            }

            response.setStatus(200);
            response.setContentType("text/plain;charset=UTF-8");
            response.setCharacterEncoding(testStr);
            PrintWriter out = response.getWriter();
            out.println();

        }



    }

}
