package com.example.myfirstandroidapp;

public interface HttpServlet {
}
