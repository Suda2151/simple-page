package cmu.edu.tsudare;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class HttpRequest {
    MainActivity ma = null;
    //HttpRequest hr = new HttpRequest();
    HttpRequest hr;
    public void search(String seachWord, MainActivity ma){
        this.ma = ma;
        hr.doGet(seachWord,ma);

    }

    public static String doGet(String searchWord, MainActivity ma){

        String response = "";
        HttpURLConnection conn;
        int status = 0;

        try {
            URL url = new URL("http://localhost:8080/Project4Task1/MobileServlet"+"//"+searchWord);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            // tell the server what format we want back
            conn.setRequestProperty("Accept", "text/plain");

            // wait for response
            status = conn.getResponseCode();

            // If things went poorly, don't try to read any response, just return.
            if (status != 200) {
                // not using msg
                String msg = conn.getResponseMessage();
                return String.valueOf(conn.getResponseCode());
            }
            String output = "";
            // things went well so let's read the response
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));

            while ((output = br.readLine()) != null) {
                response += output;

            }

            conn.disconnect();

        }
        catch (MalformedURLException e) {
            e.printStackTrace();
        }   catch (IOException e) {
            e.printStackTrace();
        }

        return String.valueOf(status);

    }

}
