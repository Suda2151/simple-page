package cmu.edu.tsudare;

import android.graphics.Bitmap;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class MobileServlet  {
    static  int status =0;
    MobileModel mm = new MobileModel();
    MainActivity ma = null;
    //MobileServlet ms = new MobileServlet();

    public void search(String searchWord, MainActivity ma){
        this.ma = ma;
        mm.search(searchWord,ma);
    }
/*
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("console: doGet is working");

        String result ="";
        System.out.println(request.getPathInfo().toString());
        String name = (request.getPathInfo()).substring(1);

        mm.search(name,mm);

        while(ms.getStatus() == 0){}

        response.setStatus(ms.getStatus());
        response.setContentType("text/plain;charset=UTF-8");

        PrintWriter out = response.getWriter();
        out.println(result);




    }
*/

    public void resultOperation(Bitmap pic){
        ma.showingPicture(pic);
    }

    public void setStatus(int status){
        this.status = status;}

     public int getStatus(){
        return  this.status;  }

}
