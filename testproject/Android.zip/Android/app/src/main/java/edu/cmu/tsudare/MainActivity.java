package edu.cmu.tsudare;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.widget.*;
import androidx.core.widget.ImageViewCompat;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import org.jose4j.json.internal.json_simple.JSONObject;

import java.net.URI;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        final MainActivity main = this;

        Button btnSubmit;
        final TextView txtDisplay;
        final EditText editText;

        btnSubmit = (Button)findViewById(R.id.btnSubmit);
        //txtDisplay = (TextView)findViewById(R.id.txtDisplay0);
        txtDisplay = (TextView)findViewById(R.id.txtDisplay);
        editText = (EditText)findViewById(R.id.edittxt);

        btnSubmit.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                String searchWord = editText.getText().toString();

                HttpRequest hr = new HttpRequest();
                hr.search(searchWord,main);

                //HttpRequest hr = new HttpRequest();
                //hr.search(searchWord,main);


                Toast.makeText(MainActivity.this, "You clicked submit!" , Toast.LENGTH_SHORT).show();

            }
        });
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



    // public void showingPicture(Bitmap pic){
    public void showingPicture(Bitmap bitmap){


        //System.out.println("JSON data at MAINActivity is :" + jsonObject);


        //Bitmap bitmap = null;
        //String strData = jsonObject.get("bitmap").toString();
/*
        try{
            byte [] encodeByte= Base64.decode(strData,Base64.DEFAULT);
            bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);

        }catch(Exception e){
            e.getMessage();

        }

*/
        System.out.println("are you ready???");


        ImageView imageView = (ImageView) findViewById(R.id.pic);

        //TextView textView = (EditText) findViewById(R.id.edittxt);

        //String bitmap = "https://images.unsplash.com/photo-1578232977692-64b272f85e4f?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=400&fit=max&ixid=eyJhcHBfaWQiOjExOTg3OH0";



        if(bitmap != null){
            imageView.setImageBitmap(bitmap);
            imageView.setVisibility(View.VISIBLE);
        }else{
            imageView.setVisibility(View.INVISIBLE);

        }
        //textView.setText("");
        imageView.invalidate();

    }
}
